# Independent workers boundary

This dashboard can display runtime identity recorded by a run, but it does not implement worker registration, scheduling, remote transport, or distributed backward. A comparison across independently produced runs is descriptive unless their stored configuration, data identity, tokenizer, precision, backend, and observed budgets make a controlled comparison appropriate.
