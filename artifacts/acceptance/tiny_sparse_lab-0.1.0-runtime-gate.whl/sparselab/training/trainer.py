"""Engine-neutral single-host training lifecycle with explicit update boundaries."""

from __future__ import annotations

import hashlib
import json
import shutil
import signal
import socket
import time
import uuid
from contextlib import ExitStack
from dataclasses import asdict
from pathlib import Path

import numpy as np

from sparselab.config.models import RunConfig
from sparselab.data.packing import (
    BatchCursor,
    PreparedData,
    TokenBlockDataset,
    epoch_order,
    load_prepared_data,
    prepare_data,
)
from sparselab.data.tokenizer import load_tokenizer
from sparselab.engines.base import EngineState, Microbatch
from sparselab.engines.pytorch import PyTorchEngine
from sparselab.memory import (
    calibrated_estimate,
    calibration_key,
    parameter_inventory,
    validate_offload_headroom,
)
from sparselab.runtime import seed_everything
from sparselab.training.checkpoints import (
    CheckpointManager,
    CheckpointRecord,
    LineageBest,
    TrainingSnapshot,
    _atomic_json,
    choose_lineage_best,
    existing_run_recovery_report,
)
from sparselab.training.continuation import load_continuation
from sparselab.training.manifest import (
    ArtifactIdentity,
    RunManifest,
    architecture_sha256,
    canonical_json,
    config_sha256,
    sha256_file,
    source_identity,
    write_manifest,
)
from sparselab.training.metrics import ExperimentStore
from sparselab.training.stages import ExperimentStage, StageHistory


def _load_run_data(run: Path, config: RunConfig) -> PreparedData:
    return load_prepared_data(
        run / "data", byte_enabled=config.model.memory in {"byte", "portable"}
    )


def _copy_artifacts(
    run: Path, config: RunConfig, data: PreparedData, source_run: Path | None = None
) -> tuple[ArtifactIdentity, ...]:
    artifacts: list[ArtifactIdentity] = []
    tokenizer_source = (
        source_run / "tokenizer.json"
        if source_run is not None
        else config.tokenizer.path
    )
    tokenizer = run / "tokenizer.json"
    shutil.copy2(tokenizer_source, tokenizer)
    if source_run is None:
        for source in (config.tokenizer.path.with_name("tokenizer_manifest.json"),):
            if source.is_file():
                shutil.copy2(source, run / source.name)
    elif (source_run / "tokenizer_manifest.json").is_file():
        shutil.copy2(
            source_run / "tokenizer_manifest.json", run / "tokenizer_manifest.json"
        )
    shutil.copytree(data.root, run / "data")
    package_source = (
        source_run / "portable_package"
        if source_run is not None
        else config.model.memory_package_path
    )
    if package_source is not None and package_source.exists():
        destination = run / "portable_package"
        if package_source.is_dir():
            shutil.copytree(package_source, destination)
        else:
            shutil.copy2(package_source, destination)
    for path in sorted(
        item
        for item in run.rglob("*")
        if item.is_file()
        and item != run / "manifest.json"
        and not item.is_relative_to(run / "checkpoints")
    ):
        artifacts.append(
            ArtifactIdentity(
                str(path.relative_to(run)), sha256_file(path), path.stat().st_size
            )
        )
    return tuple(artifacts)


def _checkpoint_due(
    config: RunConfig,
    step: int,
    tokens: int,
    elapsed: float,
    watermarks: dict[str, float],
) -> bool:
    checks = (
        (config.checkpoint.every_steps, step - watermarks.get("step", 0)),
        (config.checkpoint.every_tokens, tokens - watermarks.get("tokens", 0)),
        (
            config.checkpoint.every_minutes,
            (elapsed - watermarks.get("minutes", 0)) / 60,
        ),
    )
    return any(interval is not None and value >= interval for interval, value in checks)


def _save(
    manager: CheckpointManager,
    engine: object,
    config: RunConfig,
    run_id: str,
    cursor: BatchCursor,
    step: int,
    tokens: int,
    watermarks: dict[str, float],
    validation_loss: float | None = None,
    *,
    source_digest: str,
    parent_digest: str | None,
    wall_seconds: float,
    update_seconds: float,
    lineage_best: LineageBest | None = None,
) -> CheckpointRecord:
    state = engine.export_training_state()
    config_payload = config.model_dump(mode="json")
    snapshot = TrainingSnapshot(
        model={},
        weight_source=engine.export_weights(),
        optimizer=state.optimizer,
        schedule={
            "kind": "warmup_cosine_v1",
            "completed_updates": step,
            "max_steps": config.training.max_steps,
            "warmup_steps": config.optimizer.warmup_steps,
            "peak": config.optimizer.peak,
            "floor": config.optimizer.floor,
        },
        step=step,
        tokens_seen=tokens,
        cursor=(cursor.epoch, cursor.next_block),
        config=config_payload,
        run_id=run_id,
        rng=state.rng,
        scaler=state.scaler,
        validation_loss=validation_loss,
        cadence=watermarks.copy(),
        engine=config.runtime.engine,
        backend=config.runtime.backend,
        optimizer_parameter_names=state.optimizer_parameter_names,
        config_sha256=config_sha256(config_payload),
        architecture_sha256=architecture_sha256(config_payload),
        source_identity_sha256=source_digest,
        manifest_sha256=manager.manifest_sha256,
        parent_checkpoint_sha256=parent_digest,
        cumulative_wall_seconds=wall_seconds,
        cumulative_update_seconds=update_seconds,
        lineage_best=lineage_best,
    )
    return manager.save(snapshot, validation_loss)


def _write_validation_report(
    run: Path,
    record: CheckpointRecord,
    result: dict[str, object],
    config: RunConfig,
    source_digest: str,
) -> Path:
    evaluations = run / "evaluations"
    evaluations.mkdir(parents=True, exist_ok=True)
    report = (
        evaluations
        / f"validation_step_{record.step:08d}_gen_{record.generation_id:06d}.json"
    )
    identities = {
        "data/validation.npy": sha256_file(run / "data" / "validation.npy"),
        "tokenizer.json": sha256_file(run / "tokenizer.json"),
        "source_identity_sha256": source_digest,
        "protocol": "next-token-cross-entropy-v1",
    }
    for name in ("validation_supervision.npy", "validation_byte_addresses.npy"):
        artifact = run / "data" / name
        if artifact.is_file():
            identities[f"data/{name}"] = sha256_file(artifact)
    payload: dict[str, object] = {
        "kind": "held_out_validation_v2",
        "checkpoint": record.relative_path,
        "checkpoint_sha256": record.manifest_sha256,
        "step": record.step,
        "tokens_seen": record.tokens_seen,
        "identities": identities,
        "batch_size": config.training.micro_batch_size,
        "max_batches": config.evaluation.max_batches,
        "seq_len": config.training.seq_len,
        **result,
    }
    payload["sha256"] = hashlib.sha256(canonical_json(payload)).hexdigest()
    content = canonical_json(payload) + b"\n"
    if report.exists():
        if report.read_bytes() != content:
            raise FileExistsError(
                f"immutable validation report already exists: {report}"
            )
        return report
    temporary = report.with_name(report.name + f".{uuid.uuid4().hex}.tmp")
    with temporary.open("wb") as handle:
        handle.write(content)
        handle.flush()
        __import__("os").fsync(handle.fileno())
    temporary.replace(report)
    return report


def train(
    config: RunConfig,
    *,
    resume: Path | None = None,
    promote: Path | None = None,
    recover: Path | None = None,
    run_id: str | None = None,
    stop_after_step: int | None = None,
    worker_id: str | None = None,
    allow_runtime_drift: bool = False,
    stage_bundle: Path | None = None,
    cancel_path: Path | None = None,
) -> str:
    """Run one independent experiment; staging pilots use the private execution core."""
    return _train_impl(
        config,
        resume=resume,
        promote=promote,
        recover=recover,
        run_id=run_id,
        stop_after_step=stop_after_step,
        worker_id=worker_id,
        allow_runtime_drift=allow_runtime_drift,
        stage_bundle=stage_bundle,
        cancel_path=cancel_path,
    )


def _train_impl(
    config: RunConfig,
    *,
    resume: Path | None = None,
    promote: Path | None = None,
    recover: Path | None = None,
    run_id: str | None = None,
    stop_after_step: int | None = None,
    worker_id: str | None = None,
    allow_runtime_drift: bool = False,
    stage_bundle: Path | None = None,
    cancel_path: Path | None = None,
    purpose: str = "training",
) -> str:
    with ExitStack() as resources:
        choices = [path for path in (resume, promote, recover) if path is not None]
        if len(choices) > 1:
            raise ValueError("resume, promote, and recover are mutually exclusive")
        if purpose not in {"training", "smoke", "warmup"}:
            raise ValueError("invalid execution purpose")
        if purpose != "training" and (choices or stage_bundle is None):
            raise ValueError(
                "pilots require immutable staged inputs and fresh initialization"
            )
        staged = None
        if stage_bundle is not None:
            from sparselab.staging import verify_stage_bundle

            staged = verify_stage_bundle(stage_bundle, config, purpose=purpose)
        requested_config = config.model_dump(mode="json")
        history = StageHistory()
        history.start(ExperimentStage.CONFIGURED)
        history.finish()
        history.start(ExperimentStage.INSPECTED)
        inventory = parameter_inventory(config)
        history.finish()
        history.start(ExperimentStage.VALIDATED)
        run_id = run_id or uuid.uuid4().hex
        if Path(run_id).name != run_id or run_id in {".", ".."}:
            raise ValueError("run_id must be a single nonempty directory name")
        run = config.logging.root_dir / run_id
        if run.exists():
            report = existing_run_recovery_report(run)
            raise FileExistsError(
                f"run exists: {run_id}; explicit recovery creates a child; "
                f"read-only recovery report: {json.dumps(report, sort_keys=True)}"
            )
        if config.runtime.engine == "pytorch":
            engine = PyTorchEngine()
        elif config.runtime.engine == "mlx":
            from sparselab.engines.mlx import MLXEngine

            engine = MLXEngine()
        else:
            raise ValueError(f"unsupported execution engine: {config.runtime.engine}")
        runtime = engine.validate(config)
        config = config.model_copy(
            update={
                "runtime": config.runtime.model_copy(
                    update={
                        "backend": runtime.backend,
                        "precision": "fp32"
                        if config.runtime.precision == "auto"
                        else config.runtime.precision,
                    }
                )
            }
        )
        current_source = source_identity()
        continuation_state = load_continuation(
            config,
            runtime,
            current_source,
            resume=resume,
            promote=promote,
            recover=recover,
            allow_runtime_drift=allow_runtime_drift,
        )
        snapshot = continuation_state.snapshot
        source_run = continuation_state.source_run
        continuation = continuation_state.kind
        artifact_source = source_run if continuation == "RESUMED" else None
        if staged is not None and continuation != "RESUMED":
            artifact_source = Path(staged["assets_root"])
            config = config.model_copy(
                update={
                    "tokenizer": config.tokenizer.model_copy(
                        update={"path": artifact_source / "tokenizer.json"}
                    ),
                    "model": config.model.model_copy(
                        update={
                            "memory_package_path": artifact_source / "portable_package"
                            if config.model.memory_package_path is not None
                            else None,
                        }
                    ),
                }
            )
        seed_everything(config.seed, deterministic_cpu=config.training.deterministic)
        if continuation == "RESUMED":
            assert source_run is not None
            data = _load_run_data(source_run, config)
        elif artifact_source is not None:
            data = _load_run_data(artifact_source, config)
        else:
            tokenizer = load_tokenizer(config.tokenizer.path)
            data = prepare_data(config, tokenizer)
        dataset = TokenBlockDataset(
            data.train,
            config.training.seq_len,
            data.train_byte_addresses,
            data.train_supervision,
        )
        validation_dataset = TokenBlockDataset(
            data.validation,
            config.training.seq_len,
            data.validation_byte_addresses,
            data.validation_supervision,
        )
        if not len(dataset):
            raise ValueError("training data contains no supervised next-token targets")
        if not len(validation_dataset):
            raise ValueError(
                "validation data contains no supervised next-token targets"
            )
        calibration_identity = calibration_key(
            config, runtime, source_digest=str(current_source["sha256"])
        )
        observations = ExperimentStore.get_calibration(
            config.logging.root_dir, calibration_identity
        )
        if staged is not None and stage_bundle is not None:
            for pilot_purpose in ("smoke", "warmup"):
                observations.extend(
                    ExperimentStore.get_calibration(
                        stage_bundle / "pilots" / pilot_purpose,
                        calibration_identity,
                    )
                )
        memory_estimate = calibrated_estimate(config, runtime, inventory, observations)
        if memory_estimate.result == "LIKELY_TO_EXCEED":
            raise MemoryError(
                "estimated training memory exceeds the safe ceiling; inspect --write-proposal before training"
            )
        offload_headroom = validate_offload_headroom(config, runtime, memory_estimate)
        history.finish()
        if continuation == "RESUMED" and config.model.memory_package_path is not None:
            assert source_run is not None
            owned_package = source_run / "portable_package"
            if not owned_package.exists():
                raise ValueError("resume run lacks immutable portable package")
            config = config.model_copy(
                update={
                    "model": config.model.model_copy(
                        update={"memory_package_path": owned_package}
                    )
                }
            )
        initial_weights = snapshot.model if snapshot is not None else None
        first_update_step = (
            snapshot.step + 1
            if snapshot is not None and continuation == "RESUMED"
            else 1
        )
        engine.initialize(config, initial_weights=initial_weights)
        resources.callback(engine.close)
        step = tokens = 0
        cursor = BatchCursor()
        parent_run_id = continuation_state.parent_run_id
        lineage_best = continuation_state.lineage_best
        cumulative_wall = 0.0
        cumulative_updates = 0.0
        watermarks: dict[str, float] = {}
        if snapshot is not None and continuation == "RESUMED":
            engine.restore_training_state(
                EngineState(
                    snapshot.optimizer,
                    snapshot.rng or {},
                    snapshot.scaler,
                    snapshot.optimizer_parameter_names or [],
                )
            )
            step, tokens = snapshot.step, snapshot.tokens_seen
            cursor = BatchCursor(*snapshot.cursor)
            watermarks = snapshot.cadence or {}
            cumulative_wall = snapshot.cumulative_wall_seconds or 0.0
            cumulative_updates = snapshot.cumulative_update_seconds or 0.0
        if snapshot is not None:
            snapshot.model.clear()
            snapshot.optimizer.clear()
            snapshot.rng = None
            snapshot.scaler = None
        del initial_weights, snapshot
        if continuation == "RESUMED" and (
            step >= config.training.max_steps or tokens >= config.training.max_tokens
        ):
            raise ValueError("cannot resume a completed training budget")
        if stop_after_step is not None and stop_after_step <= step:
            raise ValueError("stop-after-step must exceed current step")
        run.mkdir(parents=True)
        manager = CheckpointManager(run, keep_periodic=config.checkpoint.keep_periodic)
        resources.enter_context(manager.writer_lease())
        artifacts = _copy_artifacts(run, config, data, artifact_source)
        pilot_reports = tuple(staged["pilot_reports"]) if staged else ()
        stage_digest = str(staged["sha256"]) if staged else None
        if staged is not None:
            evidence = run / "stage_evidence.json"
            _atomic_json(
                evidence,
                {
                    "stage_bundle_sha256": stage_digest,
                    "pilot_reports": pilot_reports,
                    "stages": staged["stages"],
                },
            )
            artifacts = (
                *artifacts,
                ArtifactIdentity(
                    evidence.name,
                    sha256_file(evidence),
                    evidence.stat().st_size,
                ),
            )
        (run / "resolved_config.yaml").write_text(
            json.dumps(config.model_dump(mode="json"), sort_keys=True, indent=2) + "\n"
        )
        manifest = RunManifest(
            run_id,
            config.name,
            runtime,
            requested_config,
            config.model_dump(mode="json"),
            architecture_sha256(config.model_dump(mode="json")),
            current_source,
            worker_id or socket.gethostname(),
            continuation,
            parent_run_id=parent_run_id,
            checkpoint_sha256=continuation_state.parent_checkpoint_sha256,
            purpose=purpose,
            stage_bundle_sha256=stage_digest,
            pilot_reports=pilot_reports,
            artifacts=artifacts,
            resource_decisions=continuation_state.decisions
            + (
                (
                    {
                        "requested": "activation_offload",
                        "effective": True,
                        "reason": "conservative host headroom checked before model allocation",
                        "host_budget": offload_headroom,
                    },
                )
                if offload_headroom is not None
                else ()
            ),
        )
        manifest_digest = write_manifest(run / "manifest.json", manifest)
        manager.manifest_sha256 = manifest_digest
        store = ExperimentStore(config.logging.root_dir)
        store.create_run(
            run_id,
            config.model_dump(mode="json"),
            {
                "inspection": asdict(inventory),
                "runtime": runtime.as_dict(),
                "manifest_sha256": manifest_digest,
                "memory_estimate": asdict(memory_estimate),
                "purpose": purpose,
            },
            parent_run_id,
        )
        store.register_manifest(run_id, manifest_digest, manifest.payload())
        for sequence, stage_record in enumerate(history.records):
            store.record_stage(
                run_id,
                sequence,
                stage_record.stage,
                stage_record.status,
                stage_record.step,
                stage_record.tokens_seen,
                stage_record.started_at,
                stage_record.finished_at,
                stage_record.payload,
            )
        for decision in continuation_state.decisions:
            store.log_event(
                run_id, step, tokens, cumulative_wall, str(decision["kind"]), decision
            )
        started = time.perf_counter()
        interrupted = False
        latest_record: CheckpointRecord | None = None
        local_best: CheckpointRecord | None = None
        observed_peaks: dict[str, float] = {}

        def elapsed_seconds() -> float:
            return cumulative_wall + time.perf_counter() - started

        def progress(status: str = "running") -> None:
            _atomic_json(
                run / "progress.json",
                {
                    "manifest_sha256": manifest_digest,
                    "status": status,
                    "step": step,
                    "tokens_seen": tokens,
                    "cumulative_wall_seconds": elapsed_seconds(),
                    "cumulative_update_seconds": cumulative_updates,
                    "current_stage": asdict(history.current)
                    if history.current
                    else None,
                    "stages": [asdict(item) for item in history.records],
                    "latest": asdict(latest_record) if latest_record else None,
                    "best": asdict(local_best) if local_best else None,
                    "lineage_best": lineage_best.as_dict() if lineage_best else None,
                },
            )

        def finish_stage(status: str = "complete", reason: str | None = None) -> None:
            record = history.finish(
                status, reason=reason, step=step, tokens_seen=tokens
            )
            payload = dict(record.payload or {})
            if reason is not None:
                payload["reason"] = reason
            store.record_stage(
                run_id,
                len(history.records) - 1,
                record.stage,
                record.status,
                step,
                tokens,
                record.started_at,
                record.finished_at,
                payload,
            )

        def enter_stage(
            stage: ExperimentStage, payload: dict[str, object] | None = None
        ) -> None:
            if history.current is not None:
                finish_stage()
            current = history.start(
                stage, step=step, tokens_seen=tokens, payload=payload
            )
            store.log_event(
                run_id,
                step,
                tokens,
                elapsed_seconds(),
                "stage_started",
                asdict(current),
            )
            progress()

        def save_boundary(validation: dict[str, object] | None) -> CheckpointRecord:
            nonlocal latest_record, local_best, lineage_best, watermarks
            enter_stage(ExperimentStage.CHECKPOINTED)
            elapsed = elapsed_seconds()
            watermarks = {
                "step": float(step),
                "tokens": float(tokens),
                "minutes": elapsed,
            }
            loss = float(validation["loss"]) if validation else None
            record = _save(
                manager,
                engine,
                config,
                run_id,
                cursor,
                step,
                tokens,
                watermarks,
                loss,
                source_digest=str(current_source["sha256"]),
                parent_digest=continuation_state.parent_checkpoint_sha256,
                wall_seconds=elapsed,
                update_seconds=cumulative_updates,
                lineage_best=lineage_best,
            )
            latest_record = record
            if loss is not None:
                if local_best is None or loss < float(local_best.validation_loss):
                    local_best = record
                lineage_best = choose_lineage_best(
                    lineage_best,
                    LineageBest(run_id, record.manifest_sha256, step, loss),
                )
                _write_validation_report(
                    run, record, validation, config, str(current_source["sha256"])
                )
            store.record_checkpoint(run_id, record)
            store.log_event(
                run_id,
                step,
                tokens,
                elapsed_seconds(),
                "checkpoint_saved",
                asdict(record),
            )
            progress()
            return record

        def finish_run(status: str, reason: str | None = None) -> None:
            if status == "failed" and history.current is not None:
                finish_stage("failed", reason)
            enter_stage(
                {
                    "completed": ExperimentStage.COMPLETE,
                    "interrupted": ExperimentStage.INTERRUPTED,
                    "failed": ExperimentStage.FAILED,
                }[status]
            )
            finish_stage("complete" if status == "completed" else status, reason)
            store.finish_run(
                run_id,
                status,
                str(manager.root / "latest.json") if latest_record else None,
            )
            store.log_event(
                run_id,
                step,
                tokens,
                elapsed_seconds(),
                f"run_{status}",
                {"reason": reason},
            )
            if latest_record is not None and status != "completed":
                store.log_event(
                    run_id,
                    step,
                    tokens,
                    elapsed_seconds(),
                    "resumable",
                    {
                        "checkpoint": latest_record.relative_path,
                        "checkpoint_digest": latest_record.manifest_sha256,
                        "resume_level": latest_record.resume_level,
                    },
                )
            if observed_peaks:
                store.record_calibration(
                    calibration_identity,
                    run_id,
                    {
                        "estimate": asdict(memory_estimate),
                        "observed": observed_peaks,
                        "peak_method": "native"
                        if "memory/device_peak_allocated_bytes" in observed_peaks
                        else "sampled_lower_bound",
                        "runtime": runtime.as_dict(),
                    },
                )
            progress(status)

        def evaluation_batches() -> list[Microbatch]:
            batches: list[Microbatch] = []
            limit = config.evaluation.max_batches
            for offset in range(
                0, len(validation_dataset), config.training.micro_batch_size
            ):
                if limit is not None and len(batches) >= limit:
                    break
                records = [
                    validation_dataset.numpy_block(index)
                    for index in range(
                        offset,
                        min(
                            offset + config.training.micro_batch_size,
                            len(validation_dataset),
                        ),
                    )
                ]
                batches.append(
                    Microbatch(
                        np.stack([record[0] for record in records]),
                        np.stack([record[1] for record in records]),
                        None
                        if records[0][2] is None
                        else np.stack([record[2] for record in records]),
                    )
                )
            return batches

        def evaluate_and_record(elapsed: float) -> dict[str, object]:
            enter_stage(ExperimentStage.EVALUATING)
            result = engine.evaluate(evaluation_batches()).to_report()
            metrics: dict[str, float] = {"validation/loss": float(result["loss"])}
            if isinstance(result.get("perplexity"), (int, float)):
                metrics["validation/perplexity"] = float(result["perplexity"])
            store.log_metrics(run_id, step, tokens, elapsed, metrics)
            store.log_event(
                run_id, step, tokens, elapsed, "validation_completed", result
            )
            return result

        enter_stage(ExperimentStage.TRAINING)

        def request_stop(_signum: int, _frame: object) -> None:
            nonlocal interrupted
            interrupted = True

        old_int, old_term = (
            signal.signal(signal.SIGINT, request_stop),
            signal.signal(signal.SIGTERM, request_stop),
        )
        try:
            initial_validation = evaluate_and_record(cumulative_wall)
            save_boundary(initial_validation)
            enter_stage(ExperimentStage.TRAINING)
            while (
                step < config.training.max_steps and tokens < config.training.max_tokens
            ):
                if cancel_path is not None and cancel_path.exists():
                    interrupted = True
                if interrupted:
                    finish_run(
                        "interrupted",
                        "cancelled"
                        if cancel_path is not None and cancel_path.exists()
                        else "signal",
                    )
                    return run_id
                order = epoch_order(len(dataset), config.seed, cursor.epoch)
                remaining = config.training.max_tokens - tokens
                window_size = (
                    config.training.micro_batch_size
                    * config.training.gradient_accumulation
                )
                candidate_indices = order[
                    cursor.next_block : cursor.next_block + window_size
                ].tolist()
                if not candidate_indices:
                    cursor = BatchCursor(cursor.epoch + 1, 0)
                    continue
                records: list[tuple[np.ndarray, np.ndarray, np.ndarray | None]] = []
                valid_targets = 0
                for index in candidate_indices:
                    inputs, targets, addresses = dataset.numpy_block(index)
                    labels = targets.copy()
                    available = int(np.count_nonzero(labels != -100))
                    allowed = min(remaining - valid_targets, available)
                    if allowed < available:
                        positions = np.flatnonzero(labels != -100)
                        labels[positions[allowed:]] = -100
                    records.append((inputs, labels, addresses))
                    valid_targets += allowed
                    if valid_targets == remaining:
                        break
                if valid_targets == 0:
                    raise RuntimeError(
                        "selected training window has no supervised targets"
                    )
                microbatches = [
                    Microbatch(
                        np.stack(
                            [
                                record[0]
                                for record in records[
                                    offset : offset + config.training.micro_batch_size
                                ]
                            ]
                        ),
                        np.stack(
                            [
                                record[1]
                                for record in records[
                                    offset : offset + config.training.micro_batch_size
                                ]
                            ]
                        ),
                        None
                        if records[offset][2] is None
                        else np.stack(
                            [
                                record[2]
                                for record in records[
                                    offset : offset + config.training.micro_batch_size
                                ]
                            ]
                        ),
                    )
                    for offset in range(
                        0, len(records), config.training.micro_batch_size
                    )
                ]
                retry_seconds = 0.0
                for retries in range(3):
                    update = engine.train_update(microbatches, step + 1, valid_targets)
                    retry_seconds += update.elapsed_seconds
                    if update.outcome == "APPLIED":
                        break
                else:
                    raise FloatingPointError(
                        "GradScaler overflow persisted after three attempts"
                    )
                metric_values = dict(update.metrics)
                metric_values["optimizer/overflow_retries"] = float(retries)
                metric_values["performance/step_seconds"] = retry_seconds
                metric_values["performance/tokens_per_second"] = valid_targets / max(
                    retry_seconds, 1e-9
                )
                cumulative_updates += retry_seconds
                step, tokens = step + 1, tokens + update.committed_targets
                cursor = BatchCursor(cursor.epoch, cursor.next_block + len(records))
                elapsed = cumulative_wall + time.perf_counter() - started
                store.log_metrics(run_id, step, tokens, elapsed, metric_values)
                for name, value in metric_values.items():
                    if name.startswith("memory/") and "peak" in name:
                        observed_peaks[name] = max(observed_peaks.get(name, 0.0), value)
                unavailable = getattr(engine, "unavailable_memory_reasons", {})
                if unavailable and step == first_update_step:
                    store.log_event(
                        run_id,
                        step,
                        tokens,
                        elapsed,
                        "memory_measurements_unavailable",
                        unavailable,
                    )
                progress()
                if cancel_path is not None and cancel_path.exists():
                    interrupted = True
                terminal = (
                    step >= config.training.max_steps
                    or tokens >= config.training.max_tokens
                    or step == stop_after_step
                    or interrupted
                )
                evaluation_due = terminal or step % config.evaluation.every_steps == 0
                validation = evaluate_and_record(elapsed) if evaluation_due else None
                new_best = validation is not None and (
                    local_best is None
                    or float(validation["loss"]) < float(local_best.validation_loss)
                )
                if (
                    _checkpoint_due(config, step, tokens, elapsed, watermarks)
                    or terminal
                    or new_best
                ):
                    save_boundary(validation)
                if terminal:
                    status = (
                        "completed"
                        if step >= config.training.max_steps
                        or tokens >= config.training.max_tokens
                        else "interrupted"
                    )
                    finish_run(
                        status,
                        None
                        if status == "completed"
                        else "cancelled"
                        if cancel_path is not None and cancel_path.exists()
                        else "signal"
                        if interrupted
                        else "stop_after_step",
                    )
                    return run_id
                if (
                    history.current is not None
                    and history.current.stage != ExperimentStage.TRAINING
                ):
                    enter_stage(ExperimentStage.TRAINING)
            raise RuntimeError(
                "training stopped without completing a valid target window"
            )
        except BaseException as error:
            finish_run("failed", str(error))
            raise
        finally:
            signal.signal(signal.SIGINT, old_int)
            signal.signal(signal.SIGTERM, old_term)
